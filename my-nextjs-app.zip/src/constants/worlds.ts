export const WORLD_LIST = ['중세', '판타지', '사이버펑크', '스팀펑크', '현대', 'SF'];
