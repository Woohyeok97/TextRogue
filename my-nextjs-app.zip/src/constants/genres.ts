export const GENRE_LIST = ['추리', '공포', '모험', '생존'];
